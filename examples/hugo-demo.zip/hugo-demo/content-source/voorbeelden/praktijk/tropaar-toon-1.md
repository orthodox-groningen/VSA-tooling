---
title: "Tropaar van de zondag - toon 1"
---

# Voorbeelden uit de praktijk

- [Home](../../../)
- [Overzicht praktijkvoorbeelden](../)
- [Volgende: Tropaar (toon 2)](../tropaar-toon-2/)

---

::: vsa-notatie
[:] Ter{/&/wijl_&_} {\\de} steen door de israëlie{/ten} {/ver}{/ze_}geld {was_}
{\en} de soldaten Uw allerzuiverst lichaam be{\waak_}{ten_}
O, Ver{/los_}{/ser_}, {\\zijt} Gij na drie {/da}{/gen} {/op_}gestaan
{\om} aan de wereld het Leven te {\schen_}{\ken_}
Daarom {/roe_}{/pen_} {\\de} hemelse mach{/ten} {/U} {/toe_}:
{\O} Levenschenker, {\e_}re zij {\U_},
{/e_}{/re_} {\\zij} Uw verrijze{/nis}, {/o} {/Chris_}{tus_},
{\e}re {\zij} {/Uw} {/Ko_}ning{schap_},
{\e}re zij {\Uw} {/Voor}{/zie_}nig{heid_},
// {\Gij} enig Mens{\lie_}{ven_}{\de_} [:]
:::

---

```text
[:] Ter{/&/wijl_&_} {\\de} steen door de israëlie{/ten} {/ver}{/ze_}geld {was_}
{\en} de soldaten Uw allerzuiverst lichaam be{\waak_}{ten_}
O, Ver{/los_}{/ser_}, {\\zijt} Gij na drie {/da}{/gen} {/op_}gestaan
{\om} aan de wereld het Leven te {\schen_}{\ken_}
Daarom {/roe_}{/pen_} {\\de} hemelse mach{/ten} {/U} {/toe_}:
{\O} Levenschenker, {\e_}re zij {\U_},
{/e_}{/re_} {\\zij} Uw verrijze{/nis}, {/o} {/Chris_}{tus_},
{\e}re {\zij} {/Uw} {/Ko_}ning{schap_},
{\e}re zij {\Uw} {/Voor}{/zie_}nig{heid_},
// {\Gij} enig Mens{\lie_}{ven_}{\de_} [:]
```

---
