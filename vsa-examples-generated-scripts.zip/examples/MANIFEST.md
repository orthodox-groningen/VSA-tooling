# Inhoud

- `README.md`
- `examples/hugo-demo/content-source/voorbeelden/_index.md`
- `examples/hugo-demo/content-source/voorbeelden/praktijk/_index.md`
- `examples/hugo-demo/layouts/_default/baseof.html`