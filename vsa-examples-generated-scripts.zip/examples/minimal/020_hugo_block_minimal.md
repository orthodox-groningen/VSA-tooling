::: vsa-notatie
[:] {tekst} [:]
:::
