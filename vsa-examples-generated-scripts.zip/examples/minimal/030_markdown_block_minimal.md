# Voorbeeld

::: vsa-notatie
[:] {tekst} [:]
:::
