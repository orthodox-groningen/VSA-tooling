Kleine geldige parser-voorbeelden.
