---
title: "Tropaar van de zondag - toon 4"
---

# Voorbeelden uit de praktijk

- [Home](../../../)
- [Overzicht praktijkvoorbeelden](../)
- [Vorige: Tropaar (toon 3)](../tropaar-toon-3/)
- [Volgende: Tropaar (toon 5)](../tropaar-toon-5/)

---

{{< vsa src="/vsa/voorbeelden-praktijk-tropaar-toon-4-block-1.svg" >}}

---

```text
 [\:] Toen zij van de {-&/en_&_}/{\gel_}  
{/de} blijde boodschap van de opstanding hadden ver{no_}{\men_},  
wierpen zij {van_} {/zich_} {\af_}  
{/de} veroordeling van de {voor_}ou{\ders_}.  
De vrouwen die de Heer {-&/dien_&_}{\den}  
{/rie}pen jubelend tot de a{pos_}te{\len_}:  
ver{nie_}{/tigd} is de {\dood_},  
{/want} opgestaan is {Chris_}tus {\God_},  
// om aan de wereld te schenken de grote ge{-&\na_&_}{/de_}. [\:]
```

---
