---
title: "Tropaar van de zondag - toon 8"
---

# Voorbeelden uit de praktijk

- [Home](../../../)
- [Overzicht praktijkvoorbeelden](../)
- [Vorige: Tropaar (toon 7)](../tropaar-toon-7/)

---

{{< vsa src="/vsa/voorbeelden-praktijk-tropaar-toon-8-block-1.svg" >}}

---

```text
[:] Uit {/de} {/ho}{/ge} zijt {\Gij} neergedaald, o Barm{\har}ti{\ge_}.  
Drie {/da}{/gen} {/zijt} Gij {\in} het graf ge{\ble_}{\ven_}  
om {/ons} {/van} {/het} lij{\den} \te ver{\los_}{\sen_}.  
Gij {/zijt} {/ons} {/le}ven {\en} onze verrijzenis, Heer, {\e_}re zij {\U_}. [:]
```

---
